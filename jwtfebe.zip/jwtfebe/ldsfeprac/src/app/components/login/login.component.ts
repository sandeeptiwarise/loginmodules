import { Component } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  data = {
    username:"",
    password:"" 
  
  }

  constructor(private logiserv:LoginService) { }

  dologincall(){

    //console.log("ng submit working....")
    //this.logiserv.loginapicall(this.data)
    this.logiserv.gettoken(this.data)

  }

}