import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  constructor(private snackbar: MatSnackBar) {}

  doSignIn(){

    this.snackbar.open("Loading your login page","Cancel")

  }


}
