import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ldsfeprac';

  info = ""

  doSomething(){
    alert("Button Got Clicked")
    console.log(this.info)
   
  }

}
