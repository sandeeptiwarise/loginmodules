import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private baseurl = "http://localhost:8080"
  
  constructor(private httpClient:HttpClient) { }

  gettoken(data:any){
    this.httpClient.post(`${this.baseurl}/token`,data).subscribe(
      data=>{
        console.log(data)
      },
      err=>{
        console.log(err)
      }
    )    
  }

  loginapicall(data:any){

    this.httpClient.post(`${this.baseurl}/loginprocess`,data).subscribe(
      data=>{
        console.log(data)
      },
      err=>{
        console.log(err)
      }
    )    

  }


}
